GAMLA SKOLAN - CS2 SERVER PANEL v1.0.0
=======================================

ENGLISH
  Full guide: GETTING-STARTED.md (or on GitHub:
  https://github.com/YouTubeRobski87/CS2-GUI-serverpanel-och-plugins/blob/main/docs/GETTING-STARTED.md)

  Short version:
  1. Install Node.js (https://nodejs.org), a CS2 dedicated server, Metamod and CounterStrikeSharp.
  2. Copy ServerFiles\game into your CS2 server folder (merge with the existing "game" folder).
  3. Put the Panel folder anywhere, e.g. C:\GameServers\Panel
  4. Double-click "Gamla Skolan Panel.vbs" in the Panel folder.
  5. In the panel: Settings -> Getting started. Set the server folder and paste your GSLT token.
  6. Overview -> pick a mode -> Start.

SVENSKA
  Hela guiden: KOM-IGANG.md (eller pa GitHub:
  https://github.com/YouTubeRobski87/CS2-GUI-serverpanel-och-plugins/blob/main/docs/KOM-IGANG.md)

  Kort:
  1. Installera Node.js (https://nodejs.org), en CS2-server, Metamod och CounterStrikeSharp.
  2. Kopiera ServerFiles\game till din CS2-servermapp (sla ihop med mappen "game" som finns).
  3. Lagg mappen Panel var du vill, t.ex. C:\GameServers\Panel
  4. Dubbelklicka pa "Gamla Skolan Panel.vbs" i mappen Panel.
  5. I panelen: Installningar -> Kom igang. Ange servermapp och klistra in din GSLT-token.
     Byt sprak till Svenska nere till vanster.
  6. Oversikt -> valj lage -> Starta.

The game-mode plugins (RetakesPlugin, Deathmatch, K4-Arenas ...) are made by others and
are not included - links are in the guide. / Spellagenas plugins gors av andra och ingar
inte - lankar finns i guiden.

MIT License - see LICENSE.
